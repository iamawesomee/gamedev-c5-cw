using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameCOntroller : MonoBehaviour
{
    [SerializeField] GameObject astriods; 
    [SerializeField] Vector3 spawnValues; 
    [SerializeField] int hazardCount;
    [SerializeField] int spwanWait; 
    [SerializeField] int StartWait;
    [SerializeField] int waveWait; 

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnWaves()); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    IEnumerator SpawnWaves() {
        yield return new WaitForSeconds(StartWait); 
        while(true) {
            for (int i = 0; i < hazardCount; i++) {
                Vector3 spawnPostion = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(astriods, spawnPostion, spawnRotation);
                yield return new WaitForSeconds(spwanWait); 

          }
          yield return new WaitForSeconds(waveWait); 
            

        }

        

    }
}
